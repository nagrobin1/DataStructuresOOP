//  linked_list_3.cpp

#include "linked_list_3.h"
using namespace linked_list_3;

namespace linked_list_3 {    
    
//ONLY HEADER FILE NEEDED FOR ASSIGNMENT
    
}